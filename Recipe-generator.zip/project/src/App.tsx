import React, { useState } from 'react';
import { ChefHat, Plus, X, CookingPot, RefreshCw } from 'lucide-react';

type Recipe = {
  name: string;
  ingredients: string[];
  instructions: string[];
  image: string;
};

const SAMPLE_RECIPES: Recipe[] = [
  {
    name: "Pasta Primavera",
    ingredients: ["pasta", "tomatoes", "garlic", "olive oil", "basil"],
    instructions: [
      "Boil pasta according to package instructions",
      "Sauté garlic in olive oil",
      "Add chopped tomatoes and cook until soft",
      "Toss with pasta and fresh basil"
    ],
    image: "https://images.unsplash.com/photo-1563379926898-05f4575a45d8?auto=format&fit=crop&q=80&w=1000"
  },
  {
    name: "Simple Omelette",
    ingredients: ["eggs", "cheese", "butter", "salt", "pepper"],
    instructions: [
      "Beat eggs with salt and pepper",
      "Melt butter in pan",
      "Pour eggs and cook until set",
      "Add cheese and fold"
    ],
    image: "https://images.unsplash.com/photo-1612240498936-65f5101365d2?auto=format&fit=crop&q=80&w=1000"
  },
  {
    name: "Vegetable Stir Fry",
    ingredients: ["rice", "carrots", "broccoli", "soy sauce", "ginger"],
    instructions: [
      "Cook rice according to package instructions",
      "Stir fry vegetables with ginger",
      "Add soy sauce",
      "Serve over rice"
    ],
    image: "https://images.unsplash.com/photo-1512058564366-18510be2db19?auto=format&fit=crop&q=80&w=1000"
  }
];

function App() {
  const [ingredients, setIngredients] = useState<string[]>([]);
  const [currentIngredient, setCurrentIngredient] = useState('');
  const [matchedRecipe, setMatchedRecipe] = useState<Recipe | null>(null);

  const addIngredient = () => {
    if (currentIngredient.trim() && !ingredients.includes(currentIngredient.toLowerCase().trim())) {
      setIngredients([...ingredients, currentIngredient.toLowerCase().trim()]);
      setCurrentIngredient('');
    }
  };

  const removeIngredient = (ingredient: string) => {
    setIngredients(ingredients.filter(i => i !== ingredient));
  };

  const findRecipe = () => {
    const availableRecipes = SAMPLE_RECIPES.filter(recipe => 
      recipe.ingredients.some(ingredient => 
        ingredients.includes(ingredient.toLowerCase())
      )
    );
    
    if (availableRecipes.length) {
      const randomRecipe = availableRecipes[Math.floor(Math.random() * availableRecipes.length)];
      setMatchedRecipe(randomRecipe);
    } else {
      setMatchedRecipe(null);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 p-8">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-3 mb-4">
            <ChefHat className="w-10 h-10 text-purple-600" />
            <h1 className="text-4xl font-bold text-gray-800">Recipe Generator</h1>
          </div>
          <p className="text-gray-600">Enter your available ingredients and let us suggest a recipe!</p>
        </div>

        <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
          <div className="flex gap-2 mb-6">
            <input
              type="text"
              value={currentIngredient}
              onChange={(e) => setCurrentIngredient(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && addIngredient()}
              placeholder="Enter an ingredient..."
              className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
            />
            <button
              onClick={addIngredient}
              className="bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition-colors flex items-center gap-2"
            >
              <Plus className="w-5 h-5" /> Add
            </button>
          </div>

          <div className="flex flex-wrap gap-2 mb-6">
            {ingredients.map((ingredient) => (
              <span
                key={ingredient}
                className="bg-gray-100 px-3 py-1 rounded-full flex items-center gap-2"
              >
                {ingredient}
                <button
                  onClick={() => removeIngredient(ingredient)}
                  className="text-gray-500 hover:text-red-500"
                >
                  <X className="w-4 h-4" />
                </button>
              </span>
            ))}
          </div>

          <button
            onClick={findRecipe}
            disabled={ingredients.length === 0}
            className="w-full bg-purple-600 text-white px-6 py-3 rounded-lg hover:bg-purple-700 transition-colors disabled:bg-gray-300 flex items-center justify-center gap-2"
          >
            <CookingPot className="w-5 h-5" />
            Find Recipe
          </button>
        </div>

        {matchedRecipe && (
          <div className="bg-white rounded-xl shadow-lg overflow-hidden">
            <img
              src={matchedRecipe.image}
              alt={matchedRecipe.name}
              className="w-full h-64 object-cover"
            />
            <div className="p-6">
              <h2 className="text-2xl font-bold text-gray-800 mb-4">{matchedRecipe.name}</h2>
              
              <div className="mb-6">
                <h3 className="text-lg font-semibold text-gray-700 mb-2">Ingredients:</h3>
                <ul className="list-disc list-inside text-gray-600">
                  {matchedRecipe.ingredients.map((ingredient, index) => (
                    <li key={index} className="mb-1">{ingredient}</li>
                  ))}
                </ul>
              </div>

              <div>
                <h3 className="text-lg font-semibold text-gray-700 mb-2">Instructions:</h3>
                <ol className="list-decimal list-inside text-gray-600">
                  {matchedRecipe.instructions.map((instruction, index) => (
                    <li key={index} className="mb-2">{instruction}</li>
                  ))}
                </ol>
              </div>

              <button
                onClick={findRecipe}
                className="mt-6 w-full bg-gray-100 text-gray-700 px-6 py-3 rounded-lg hover:bg-gray-200 transition-colors flex items-center justify-center gap-2"
              >
                <RefreshCw className="w-5 h-5" />
                Try Another Recipe
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;